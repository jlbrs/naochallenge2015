/**
 * File:        supervisor.cpp
 * Description: Simple supervisor to move nao across the rooms
 * Author:      Damien Augsburger 
 */

#include <webots/robot.h>
#include <webots/supervisor.h>
#include <iostream>
#include <stdlib.h>

using namespace std;

static const double NAO_1_POS[3][3] = {
  { 1.73, 0.34, 1 },
  { -1.73, 0.34, 1 },
  { -0.2, 0.34, -2 }
}
;
static const double NAO_1_ROT[3][4] = {
  { -0.57735, 0.57735, 0.57735, 2.0944 },
  { -0.57735, 0.57735, 0.57735, 2.0944 },
  { 0, 0.7071, 0.7071, 3.1415 }
};

static const double NAO_2_POS[3][3] = {
  { 2.15, 0.34, 0.5 },
  { -2.2, 0.34, 0.55 },
  { -1.17, 0.34, -2 }
};

static const double NAO_2_ROT[3][4] = {
  { 0.57735, 0.57735, 0.57735, 4.18875 },
  { 1, 0, 0, 4.71239 },
  { 1, 0, 0, 4.71239 }
};

static const double CART_TRANS[3] = { -0.6, 0, -2 };
static const double CART_ROT[4] = { 0, 1, 0, 3.1415 };

static WbNodeRef nao1 = NULL;
static WbNodeRef nao2 = NULL;
static WbNodeRef cart = NULL;
static WbFieldRef nao1_translation = NULL;
static WbFieldRef nao1_rotation = NULL;
static WbFieldRef nao2_translation = NULL;
static WbFieldRef nao2_rotation = NULL;
static WbFieldRef cart_translation = NULL;
static WbFieldRef cart_rotation = NULL;

// print the supervisor commands.
void print_instructions() {
  cout << "Nao Challenge 2014-2015" << endl;
  cout << "Press 1 to Start the \"Play with me\" activity" << endl;
  cout << "Press 2 to Start \"Play Me one of my Favourite Movies\"" << endl;
  cout << "Press 3 to Start \"Find Me the Candies!\"" << endl;
}

void start_room(int number) {
  wb_supervisor_field_set_sf_vec3f(nao1_translation, NAO_1_POS[number - 1]);
  wb_supervisor_field_set_sf_rotation(nao1_rotation, NAO_1_ROT[number - 1]);

  if (nao2) {
    wb_supervisor_field_set_sf_vec3f(nao2_translation, NAO_2_POS[number - 1]);
    wb_supervisor_field_set_sf_rotation(nao2_rotation, NAO_2_ROT[number - 1]);
  }

  if (number == 3) {
    wb_supervisor_field_set_sf_vec3f(cart_translation, CART_TRANS);
    wb_supervisor_field_set_sf_rotation(cart_rotation, CART_ROT);
  }
}

int main(int argc, const char *argv[]) {
  // we print the instructions first to avoid mixing them with the naoqisim logs.
  print_instructions();
  
  // starts the simulation
  wb_robot_init();
  int time_step = wb_robot_get_basic_time_step();
  wb_robot_keyboard_enable(time_step);
  
  nao1 = wb_supervisor_node_get_from_def("NAO_1");
  if (!nao1) {
    cerr << "Nao robot couldn't be found by the supervisor." << endl;
    return EXIT_FAILURE;
  } else {
    nao1_translation = wb_supervisor_node_get_field(nao1, "translation");
    nao1_rotation = wb_supervisor_node_get_field(nao1, "rotation");
  }

  nao2 = wb_supervisor_node_get_from_def("NAO_2");
  if (nao2) {
    nao2_translation = wb_supervisor_node_get_field(nao2, "translation");
    nao2_rotation = wb_supervisor_node_get_field(nao2, "rotation");
  }

  cart = wb_supervisor_node_get_from_def("CART");
  if (!cart) {
    cerr << "The cart couldn't be found by the supervisor." << endl;
    return EXIT_FAILURE;
  } else {
    cart_translation = wb_supervisor_node_get_field(cart, "translation");
    cart_rotation = wb_supervisor_node_get_field(cart, "rotation");
  }
  
  int key = 0;
  int input = 0;
  bool key_pressed = false;
  
  // read keyboard inputs
  while (wb_robot_step(time_step) != -1) {
    key = wb_robot_keyboard_get_key();
    if (key != 0 && !key_pressed) {
      key_pressed = true;
      input = key;
    } else if (key == 0 && key_pressed) {
      key_pressed = false;
      switch(input) {
        case '1':
        case '2':
        case '3': start_room((int) input - '0'); break;
        default: break;
      }
    }
  }
}
